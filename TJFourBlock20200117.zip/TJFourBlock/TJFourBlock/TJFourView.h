//
//  TJFourView.h
//  TJFourBlock
//
//  Created by 谭灰灰 on 2021/1/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TJFourView : UIView

@property (weak, nonatomic) IBOutlet UIView *tjBigView;
@property (weak, nonatomic) IBOutlet UIView *tjLineView1;
@property (weak, nonatomic) IBOutlet UIView *tjLineView2;
@property (weak, nonatomic) IBOutlet UIView *tjCenterView;

#pragma mark - 3传递数组
-(void)tjPassArray:(NSArray *)arr;

@end



NS_ASSUME_NONNULL_END
