//
//  TJFourView.m
//  TJFourBlock
//
//  Created by 谭灰灰 on 2021/1/14.
//

#import "TJFourView.h"
#import "UIColor+JKHEX.h"

@interface TJFourView ()

@property (nonatomic, strong) NSArray *tjFirstArr;
@property (nonatomic, strong) NSArray *tjSecondArr;
@property (nonatomic, strong) NSArray *tjThirdArr;
@property (nonatomic, strong) NSArray *tjFouthArr;

@end

//超过多少换行
const int TJBiggestWidth = 150;
//左右间距
const CGFloat TJLeftFloat = 10.0;
//上下间距
const CGFloat TJBottomFloat = 5.0;
//字高度
const CGFloat TJFontHeight = 25;
//最下面一行文字到x轴距离
const CGFloat TJTextToX = 5;

@implementation TJFourView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

#pragma mark - 1初始化
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    self = [[NSBundle mainBundle] loadNibNamed:@"TJFourView" owner:self options:nil].lastObject;
    if (self) {
        self.frame = frame;
    }
    return self;
}

#pragma mark - 2子控件宽高改变时调用
-(void)layoutSubviews{
    [self tjFirstBlock];
    [self tjSecondBlock];
    [self tjThirdBlock];
    [self tjFourthBlock];
}

#pragma mark - 3传递数组
-(void)tjPassArray:(NSArray *)arr{
    if (arr.count > 3) {

    }else{
        NSLog(@"数组个数<4");
        return;
    }
    //分成4组
    self.tjFirstArr = arr[0];
    self.tjSecondArr = arr[1];
    self.tjThirdArr = arr[2];
    self.tjFouthArr = arr[3];
    for (int j = 0 ; j < arr.count; j++) {
        NSArray *smallArr = arr[j];
        for (int i = 0 ; i < smallArr.count; i++) {
            NSDictionary *d = smallArr[i];
            NSString *string = d[@"string"];
            int font = [d[@"font"] intValue];
            NSString *colorStr = d[@"color"];
            UIColor *color = [UIColor jk_colorWithHexString:colorStr];
            CGFloat tjStringLength = [self tjGetWidthWithString:string font:[UIFont systemFontOfSize:font]];
            CGFloat tjStringHeight = [self tjGetHeightWithString:string font:[UIFont systemFontOfSize:font]];
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, tjStringLength, tjStringHeight)];
            [self.tjBigView addSubview:label];
            int cout = 1000 * (j + 1);
            [label setTag:cout + i];
            [label setTextColor:color];
            [label setText:string];
            [label setFont:[UIFont systemFontOfSize:font]];
        }
    }
}

#pragma mark - 4数组懒加载
-(NSArray *)tjFirstArr{
    if (!_tjFirstArr) {
        _tjFirstArr = [NSArray new];
    }
    return _tjFirstArr;
}

#pragma mark - 5获取字符串长度
-(CGFloat)tjGetWidthWithString:(NSString *)string font:(UIFont *)font {
    NSDictionary *attrs = @{NSFontAttributeName : font};
    return [string boundingRectWithSize:CGSizeMake(0, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size.width;
}

#pragma mark - 6获取字符串宽度
-(CGFloat)tjGetHeightWithString:(NSString *)string font:(UIFont *)font {
    NSDictionary *attrs = @{NSFontAttributeName : font};
    return [string boundingRectWithSize:CGSizeMake(0, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size.height;
}

#pragma mark - 7第一模块
-(void)tjFirstBlock{
    //左右间距
    CGFloat leftFloat = TJLeftFloat;
    //上下间距
    CGFloat bottomFloat = TJBottomFloat;
    //上一个词的左边距到中心点的距离
    CGFloat lastFloatLeft = 0;
    //词的顶部到线的距离
    CGFloat lastFloatBottom = 0;
    //设置一个可以放词的最大宽度，超过就换行
    CGFloat biggestWidth = TJBiggestWidth;
    //放bottom数据，防止同一行2个词不一样大参差不齐
    NSMutableArray *BottomArr = [NSMutableArray new];
    //记录是一行中的第几个
    int count = 0;
    for (int i = 0; i < self.tjFirstArr.count ; i++) {
        NSDictionary *d = self.tjFirstArr[i];
        NSString *string = d[@"string"];
        int font = [d[@"font"] intValue];
        CGFloat tjStringLength = [self tjGetWidthWithString:string font:[UIFont systemFontOfSize:font]];
        CGFloat tjStringHeight = TJFontHeight;
        UILabel *label = (UILabel *)[self viewWithTag:1000 + i];
        lastFloatLeft = leftFloat + tjStringLength + lastFloatLeft;
        if (lastFloatLeft > biggestWidth) {
            //换行,清空词的左边距到中心点的距离
            lastFloatBottom = bottomFloat + tjStringHeight + lastFloatBottom;
            lastFloatLeft = leftFloat + tjStringLength;
            BottomArr = [NSMutableArray new];
            NSDictionary *d = @{@"i": @(i), @"lastFloatBottom": @(lastFloatBottom)};
            [BottomArr addObject:d];
            count = 1;
        }else{
            //不换行
            count++;
            if (count >= 2) {
                lastFloatBottom = lastFloatBottom ;
            }else{
                lastFloatBottom = bottomFloat + tjStringHeight ;
            }
            NSDictionary *d = @{@"i": @(i), @"lastFloatBottom": @(lastFloatBottom)};
            [BottomArr addObject:d];
        }
        if (BottomArr.count > 1) {
            //同一行有两个词及以上
            NSDictionary *d1 = BottomArr[1];
            NSDictionary *d0 = BottomArr[0];
            CGFloat d0Float = [d0[@"lastFloatBottom"] floatValue];
            CGFloat d1Float = [d1[@"lastFloatBottom"] floatValue];
            if (d1Float < d0Float) {
                //第2个词比第一个词小
                [label setFrame:CGRectMake(self.tjCenterView.center.x - lastFloatLeft, self.tjCenterView.center.y - d1Float - (d0Float - d1Float)/2 - TJTextToX, tjStringLength, tjStringHeight)];
                lastFloatBottom += (d0Float - d1Float)/2;
            }else{
                //第2个词比第一个词大
                [label setFrame:CGRectMake(self.tjCenterView.center.x - lastFloatLeft, self.tjCenterView.center.y - lastFloatBottom - TJTextToX, tjStringLength, tjStringHeight)];
                UILabel *oneLabel = (UILabel *)[self viewWithTag:1000 + (i - 1)];
                [oneLabel setFrame:CGRectMake(oneLabel.frame.origin.x, oneLabel.frame.origin.y - (d1Float - d0Float)/2, oneLabel.frame.size.width, oneLabel.frame.size.height)];
            }
        }else{
            //一行一个
            [label setFrame:CGRectMake(self.tjCenterView.center.x - lastFloatLeft, self.tjCenterView.center.y - lastFloatBottom - TJTextToX , tjStringLength, tjStringHeight)];
        }
    }
}

#pragma mark - 8数组懒加载第二块
-(NSArray *)tjSecondArr{
    if (!_tjSecondArr) {
        _tjSecondArr = [NSArray new];
    }
    return _tjSecondArr;
}

#pragma mark - 9数组懒加载第三块
-(NSArray *)tjThirdArr{
    if (!_tjThirdArr) {
        _tjThirdArr = [NSArray new];
    }
    return _tjThirdArr;
}

#pragma mark - 10数组懒加载第四块
-(NSArray *)tjFouthArr{
    if (!_tjFouthArr) {
        _tjFouthArr = [NSArray new];
    }
    return _tjFouthArr;
}

#pragma mark - 11第二模块
-(void)tjSecondBlock{
    //左右间距
    CGFloat leftFloat = TJLeftFloat;
    //上下间距
    CGFloat bottomFloat = TJBottomFloat;
    //上一个词的左边距到中心点的距离
    CGFloat lastFloatRight = 0;
    //词的顶部到线的距离
    CGFloat lastFloatBottom = 0;
    //设置一个可以放词的最大宽度，超过就换行
    CGFloat biggestWidth = TJBiggestWidth;
    //放bottom数据，防止同一行2个词不一样大参差不齐
    NSMutableArray *BottomArr = [NSMutableArray new];
    //记录是一行中的第几个
    int count = 0;
    //上一个字符串的长度
    CGFloat nextTextLength = 0;
    for (int i = 0; i < self.tjSecondArr.count ; i++) {
        NSDictionary *d = self.tjSecondArr[i];
        NSString *string = d[@"string"];
        int font = [d[@"font"] intValue];
        CGFloat tjStringLength = [self tjGetWidthWithString:string font:[UIFont systemFontOfSize:font]];
        CGFloat tjStringHeight = TJFontHeight;
        UILabel *label = (UILabel *)[self viewWithTag:2000 + i];        
        lastFloatRight = leftFloat + nextTextLength + lastFloatRight;
        nextTextLength = tjStringLength;
        if (lastFloatRight + tjStringLength > biggestWidth) {
            //换行,清空词的左边距到中心点的距离
            lastFloatBottom = bottomFloat + tjStringHeight + lastFloatBottom;
            lastFloatRight = leftFloat ;
            BottomArr = [NSMutableArray new];
            NSDictionary *d = @{@"i": @(i), @"lastFloatBottom": @(lastFloatBottom)};
            [BottomArr addObject:d];
            count = 1;
        }else{
            //不换行
            count++;
            if (count >= 2) {
                lastFloatBottom = lastFloatBottom ;
            }else{
                lastFloatBottom = bottomFloat + tjStringHeight ;
            }
            NSDictionary *d = @{@"i": @(i), @"lastFloatBottom": @(lastFloatBottom)};
            [BottomArr addObject:d];
        }
        if (BottomArr.count > 1) {
            //同一行有两个词及以上
            NSDictionary *d1 = BottomArr[1];
            NSDictionary *d0 = BottomArr[0];
            CGFloat d0Float = [d0[@"lastFloatBottom"] floatValue];
            CGFloat d1Float = [d1[@"lastFloatBottom"] floatValue];
            if (d1Float < d0Float) {
                //第2个词比第一个词小
                [label setFrame:CGRectMake(self.tjCenterView.center.x + lastFloatRight, self.tjCenterView.center.y - d1Float - (d0Float - d1Float)/2 - TJTextToX, tjStringLength, tjStringHeight)];
                lastFloatBottom += (d0Float - d1Float)/2;
            }else{
                //第2个词比第一个词大
                [label setFrame:CGRectMake(self.tjCenterView.center.x + lastFloatRight, self.tjCenterView.center.y - lastFloatBottom - TJTextToX, tjStringLength, tjStringHeight)];
                UILabel *oneLabel = (UILabel *)[self viewWithTag:1000 + (i - 1)];
                [oneLabel setFrame:CGRectMake(oneLabel.frame.origin.x, oneLabel.frame.origin.y - (d1Float - d0Float)/2, oneLabel.frame.size.width, oneLabel.frame.size.height)];
            }
        }else{
            //一行一个
            [label setFrame:CGRectMake(self.tjCenterView.center.x + lastFloatRight, self.tjCenterView.center.y - lastFloatBottom - TJTextToX , tjStringLength, tjStringHeight)];
        }
    }
}

#pragma mark - 12第三模块
-(void)tjThirdBlock{
    //左右间距
    CGFloat leftFloat = TJLeftFloat;
    //上下间距
    CGFloat bottomFloat = TJBottomFloat;
    //上一个词的左边距到中心点的距离
    CGFloat lastFloatLeft = 0;
    //词的顶部到线的距离
    CGFloat lastFloatBottom = 0;
    //设置一个可以放词的最大宽度，超过就换行
    CGFloat biggestWidth = TJBiggestWidth;
    //放bottom数据，防止同一行2个词不一样大参差不齐
    NSMutableArray *BottomArr = [NSMutableArray new];
    //记录是一行中的第几个
    int count = 0;
    //上一个词的高度
    CGFloat tjTopStringHeight = 0;
    for (int i = 0; i < self.tjThirdArr.count ; i++) {
        NSDictionary *d = self.tjThirdArr[i];
        NSString *string = d[@"string"];
        int font = [d[@"font"] intValue];
        CGFloat tjStringLength = [self tjGetWidthWithString:string font:[UIFont systemFontOfSize:font]];
        CGFloat tjStringHeight = TJFontHeight;
        UILabel *label = (UILabel *)[self viewWithTag:3000 + i];
        lastFloatLeft = leftFloat + tjStringLength + lastFloatLeft;
        if (lastFloatLeft > biggestWidth) {
            //换行,清空词的左边距到中心点的距离
            lastFloatBottom = bottomFloat + tjStringHeight + lastFloatBottom;
            lastFloatLeft = leftFloat + tjStringLength;
            BottomArr = [NSMutableArray new];
            NSDictionary *d = @{@"i": @(i), @"lastFloatBottom": @(lastFloatBottom)};
            [BottomArr addObject:d];
            count = 1;
        }else{
            //不换行
            count++;
            if (count >= 2) {
                lastFloatBottom = lastFloatBottom ;
            }else{
                lastFloatBottom = bottomFloat + tjTopStringHeight ;
            }
            NSDictionary *d = @{@"i": @(i), @"lastFloatBottom": @(lastFloatBottom)};
            [BottomArr addObject:d];
        }
        tjTopStringHeight = tjStringHeight;
        if (BottomArr.count > 1) {
            //同一行有两个词及以上
            NSDictionary *d1 = BottomArr[1];
            NSDictionary *d0 = BottomArr[0];
            CGFloat d0Float = [d0[@"lastFloatBottom"] floatValue];
            CGFloat d1Float = [d1[@"lastFloatBottom"] floatValue];
            if (d1Float < d0Float) {
                //第2个词比第一个词小
                [label setFrame:CGRectMake(self.tjCenterView.center.x - lastFloatLeft, self.tjCenterView.center.y - d1Float - (d0Float - d1Float)/2 + TJTextToX, tjStringLength, tjStringHeight)];
                lastFloatBottom += (d0Float - d1Float)/2;
            }else{
                //第2个词比第一个词大
                [label setFrame:CGRectMake(self.tjCenterView.center.x - lastFloatLeft, self.tjCenterView.center.y + lastFloatBottom + TJTextToX, tjStringLength, tjStringHeight)];
                UILabel *oneLabel = (UILabel *)[self viewWithTag:1000 + (i - 1)];
                [oneLabel setFrame:CGRectMake(oneLabel.frame.origin.x, oneLabel.frame.origin.y - (d1Float - d0Float)/2, oneLabel.frame.size.width, oneLabel.frame.size.height)];
            }
        }else{
            //一行一个
            [label setFrame:CGRectMake(self.tjCenterView.center.x - lastFloatLeft, self.tjCenterView.center.y + lastFloatBottom + TJTextToX , tjStringLength, tjStringHeight)];
        }
    }
}

#pragma mark - 13第四个模块
-(void)tjFourthBlock{
    //左右间距
    CGFloat leftFloat = TJLeftFloat;
    //上下间距
    CGFloat bottomFloat = TJBottomFloat;
    //上一个词的左边距到中心点的距离
    CGFloat lastFloatLeft = 0;
    //词的顶部到线的距离
    CGFloat lastFloatBottom = 0;
    //设置一个可以放词的最大宽度，超过就换行
    CGFloat biggestWidth = TJBiggestWidth;
    //放bottom数据，防止同一行2个词不一样大参差不齐
    NSMutableArray *BottomArr = [NSMutableArray new];
    //记录是一行中的第几个
    int count = 0;
    //上一个词的长度
    CGFloat tjTopStringLength = 0;
    //上一个词的高度
    CGFloat tjTopStringHeight = 0;
    for (int i = 0; i < self.tjFouthArr.count ; i++) {
        NSDictionary *d = self.tjFouthArr[i];
        NSString *string = d[@"string"];
        int font = [d[@"font"] intValue];
        CGFloat tjStringLength = [self tjGetWidthWithString:string font:[UIFont systemFontOfSize:font]];
        CGFloat tjStringHeight = TJFontHeight;
        UILabel *label = (UILabel *)[self viewWithTag:4000 + i];
        lastFloatLeft = leftFloat + tjTopStringLength + lastFloatLeft;
        tjTopStringLength = tjStringLength;
        if (leftFloat + tjStringLength + lastFloatLeft > biggestWidth) {
            //换行,清空词的左边距到中心点的距离
            lastFloatBottom = bottomFloat + tjStringHeight + lastFloatBottom;
            lastFloatLeft = leftFloat ;
            BottomArr = [NSMutableArray new];
            NSDictionary *d = @{@"i": @(i), @"lastFloatBottom": @(lastFloatBottom)};
            [BottomArr addObject:d];
            count = 1;
        }else{
            //不换行
            count++;
            if (count >= 2) {
                lastFloatBottom = lastFloatBottom ;
            }else{
                lastFloatBottom = bottomFloat + tjTopStringHeight ;
            }
            NSDictionary *d = @{@"i": @(i), @"lastFloatBottom": @(lastFloatBottom)};
            [BottomArr addObject:d];
        }
        tjTopStringHeight = tjStringHeight;
        if (BottomArr.count > 1) {
            //同一行有两个词及以上
            NSDictionary *d1 = BottomArr[1];
            NSDictionary *d0 = BottomArr[0];
            CGFloat d0Float = [d0[@"lastFloatBottom"] floatValue];
            CGFloat d1Float = [d1[@"lastFloatBottom"] floatValue];
            if (d1Float < d0Float) {
                //第2个词比第一个词小
                [label setFrame:CGRectMake(self.tjCenterView.center.x + lastFloatLeft, self.tjCenterView.center.y - d1Float - (d0Float - d1Float)/2 + TJTextToX, tjStringLength, tjStringHeight)];
                lastFloatBottom += (d0Float - d1Float)/2;
            }else{
                //第2个词比第一个词大
                [label setFrame:CGRectMake(self.tjCenterView.center.x + lastFloatLeft, self.tjCenterView.center.y + lastFloatBottom + TJTextToX, tjStringLength, tjStringHeight)];
                UILabel *oneLabel = (UILabel *)[self viewWithTag:1000 + (i - 1)];
                [oneLabel setFrame:CGRectMake(oneLabel.frame.origin.x, oneLabel.frame.origin.y - (d1Float - d0Float)/2, oneLabel.frame.size.width, oneLabel.frame.size.height)];
            }
        }else{
            //一行一个
            [label setFrame:CGRectMake(self.tjCenterView.center.x + lastFloatLeft, self.tjCenterView.center.y + lastFloatBottom + TJTextToX , tjStringLength, tjStringHeight)];
        }
    }
}

@end

