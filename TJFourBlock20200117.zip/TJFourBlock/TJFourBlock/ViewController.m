//
//  ViewController.m
//  TJFourBlock
//
//  Created by 谭灰灰 on 2021/1/14.
//

#import "ViewController.h"
#import "TJFourView.h"

@interface ViewController ()

@property (nonatomic, strong) TJFourView *tjFourView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //布局
    [self tjBuildUI];
    //加载数据
    [self tjParseData];

}

#pragma mark - 1布局
-(void)tjBuildUI{
    self.tjFourView = [[TJFourView alloc] initWithFrame:CGRectMake(0, 50, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width)];
    [self.view addSubview:self.tjFourView];
}

#pragma mark - 2加载数据
-(void)tjParseData{
    NSArray *arr1 = @[@{@"string": @"突然暴富", @"color": @"#F8ABA6", @"font": @"11"},
                      @{@"string": @"突霸奔载有革有", @"color": @"#00034A", @"font": @"17"},
                      @{@"string": @"最近的", @"color": @"#F47920", @"font": @"10"},
                      @{@"string": @"大傻子", @"coxlor": @"#00034A", @"font": @"13"},
                      @{@"string": @"厨艺", @"color": @"#5C7A29", @"font": @"24"},
                      @{@"string": @"地有有", @"color": @"#F8ABA6", @"font": @"19"},
                      @{@"string": @"这", @"color": @"#00034A", @"font": @"17"},
    ];
    NSArray *arr2 = @[@{@"string": @"大傻", @"color": @"#F8ABA6", @"font": @"16"},
                      @{@"string": @"最", @"color": @"#F8ABA6", @"font": @"24"},
                      @{@"string": @"突然暴", @"color": @"#F8ABA6", @"font": @"11"},
                      @{@"string": @"突霸奔载有革有", @"color": @"#00034A", @"font": @"17"},
                      @{@"string": @"最", @"color": @"#F47920", @"font": @"10"},
    ];
    NSArray *arr3 = @[@{@"string": @"大地", @"color": @"#F47920", @"font": @"16"},
                      @{@"string": @"厨艺", @"color": @"#00034A", @"font": @"24"},
                      @{@"string": @"突", @"color": @"#F47920", @"font": @"18"},
                      @{@"string": @"突然大地大地", @"color": @"#00034A", @"font": @"18"},
                      @{@"string": @"最近的", @"color": @"#F47920", @"font": @"24"}
    ];
    NSArray *arr4 = @[@{@"string": @"大傻子", @"color": @"#5C7A29", @"font": @"16"},
                      @{@"string": @"厨艺", @"color": @"#5C7A29", @"font": @"24"},
                      @{@"string": @"突然暴富", @"color": @"#00034A", @"font": @"11"},
                      @{@"string": @"突然去世主主", @"color": @"#5C7A29", @"font": @"12"},
                      @{@"string": @"最近的", @"color": @"#00034A", @"font": @"24"}
    ];
    NSArray *arr = @[arr1, arr2, arr3, arr4];
    [self.tjFourView tjPassArray:arr];
}





@end
