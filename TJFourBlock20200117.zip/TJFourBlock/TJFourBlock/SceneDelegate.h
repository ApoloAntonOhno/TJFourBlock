//
//  SceneDelegate.h
//  TJFourBlock
//
//  Created by 谭灰灰 on 2021/1/14.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

